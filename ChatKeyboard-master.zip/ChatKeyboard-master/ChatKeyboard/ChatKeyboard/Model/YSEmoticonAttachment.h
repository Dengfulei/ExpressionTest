//
//  YSEmoticonAttachment.h
//  ChatKeyboard
//
//  Created by jiangys on 16/6/1.
//  Copyright © 2016年 jiangys. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YSEmoticonModel.h"

@interface YSEmoticonAttachment : NSTextAttachment

@property (nonatomic, strong) YSEmoticonModel *emoticonModel;

@end
