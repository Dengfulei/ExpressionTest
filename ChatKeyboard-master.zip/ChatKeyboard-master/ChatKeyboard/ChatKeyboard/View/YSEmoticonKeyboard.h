//
//  YSEmoticonKeyboard.h
//  ChatKeyboard
//
//  Created by jiangys on 16/5/31.
//  Copyright © 2016年 jiangys. All rights reserved.
//  表情键盘（整体）: YSEmoticonListView + YSEmoticonTabBar

#import <UIKit/UIKit.h>

@interface YSEmoticonKeyboard : UIView

@end
