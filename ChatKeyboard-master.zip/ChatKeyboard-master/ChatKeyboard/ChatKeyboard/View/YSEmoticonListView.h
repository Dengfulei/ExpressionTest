//
//  YSEmoticonListView.h
//  ChatKeyboard
//
//  Created by jiangys on 16/5/31.
//  Copyright © 2016年 jiangys. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YSEmoticonListView : UIView
/** 表情(里面存放的EmoticonModel模型) */
@property (nonatomic, strong) NSArray *emoticonArray;
@end
