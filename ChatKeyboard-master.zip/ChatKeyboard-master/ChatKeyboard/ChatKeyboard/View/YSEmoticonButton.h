//
//  YSEmoticonButton.h
//  ChatKeyboard
//
//  Created by jiangys on 16/6/1.
//  Copyright © 2016年 jiangys. All rights reserved.
//

#import <UIKit/UIKit.h>
@class YSEmoticonModel;

@interface YSEmoticonButton : UIButton

@property(nonatomic, strong) YSEmoticonModel *emoticonModel;

@end
