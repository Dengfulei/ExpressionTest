//
//  YSEmoticonTabBarButton.h
//  ChatKeyboard
//
//  Created by jiangys on 16/5/31.
//  Copyright © 2016年 jiangys. All rights reserved.
//  重写表情底部TabBar按钮，去掉点击过度的高亮效果

#import <UIKit/UIKit.h>

@interface YSEmoticonTabBarButton : UIButton

@end
