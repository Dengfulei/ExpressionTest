//
//  YSConst.m
//  ChatKeyboard
//
//  Created by jiangys on 16/6/1.
//  Copyright © 2016年 jiangys. All rights reserved.
//

#import "YSConst.h"

// 通知
// 表情选中的通知
NSString * const YSEmoticonDidSelectNotification = @"YSEmoticonDidSelectNotification";
NSString * const YSSelectEmoticonKey = @"YSSelectEmoticonKey";

// 删除文字的通知
NSString * const YSEmoticonDidDeleteNotification = @"YSEmoticonDidDeleteNotification";
