//
//  YSComposeViewController.h
//  ChatKeyboard
//
//  Created by jiangys on 16/5/30.
//  Copyright © 2016年 jiangys. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YSComposeViewController : UIViewController

@end
