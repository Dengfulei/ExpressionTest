//
//  main.m
//  ChatKeyboard
//
//  Created by jiangys on 16/5/30.
//  Copyright © 2016年 jiangys. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
