//
//  YSConst.h
//  ChatKeyboard
//
//  Created by jiangys on 16/6/1.
//  Copyright © 2016年 jiangys. All rights reserved.
//

#import <Foundation/Foundation.h>

// 通知
// 表情选中的通知
extern NSString * const YSEmoticonDidSelectNotification;
extern NSString * const YSSelectEmoticonKey;

// 删除文字的通知
extern NSString * const YSEmoticonDidDeleteNotification;
