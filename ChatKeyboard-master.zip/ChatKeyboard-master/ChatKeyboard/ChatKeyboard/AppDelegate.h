//
//  AppDelegate.h
//  ChatKeyboard
//
//  Created by jiangys on 16/5/30.
//  Copyright © 2016年 jiangys. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

